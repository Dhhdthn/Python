import math

z = int(input())
b = int(input())
p = 3, 14
if z < 1:
    x = z / b
else:
    x = math.sqrt(math.pow(z * b, 3))
y = math.pi * -1 + math.pow(math.cos(math.pow(x, 3)), 2) + math.pow(math.sin(math.pow(x, 2)), 3)
print(y)
